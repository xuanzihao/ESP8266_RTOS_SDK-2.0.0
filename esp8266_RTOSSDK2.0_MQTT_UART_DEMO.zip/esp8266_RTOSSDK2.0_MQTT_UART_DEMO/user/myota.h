#ifndef __myota__
#define __myota__
#include "esp_common.h"
#include "upgrade.h"
#include "ota_config.h"
#include "mymqtt.h"







void ota_start();
#endif

