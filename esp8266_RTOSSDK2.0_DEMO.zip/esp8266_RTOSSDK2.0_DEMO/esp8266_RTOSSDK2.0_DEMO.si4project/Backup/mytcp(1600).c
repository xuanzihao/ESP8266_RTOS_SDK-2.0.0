#include "mytcp.h"
#include "edpkit.h"


xTaskHandle  wifiClientHandle=NULL;
static volatile int tcp_fd;

uint32_t clienttcp_task_cont=0;
int clienttcp_status=0;

int clilenttcp_get_answer=0;
uint32_t clilenttcp_get_answer_cont=0;

static int tcp_max_size=1024;
static unsigned char tcp_reveive_buffer[1024];

uint8_t tcp_client_isconnect_flag;


static int ICACHE_FLASH_ATTR new_tcp_state(int sock)
{
    int errcode = 0;
    int tcp_fd = sock;
    if(tcp_fd < 0) {
        return -1;
    }
  #if 1  
    fd_set rset, wset;
    int ready_n;

    FD_ZERO(&rset);
    FD_SET(tcp_fd, &rset);
    wset = rset;

    struct timeval timeout;
    timeout.tv_sec = 3;
    timeout.tv_usec = 0;


	/*ʹ��select�����ж�tcp����״̬*/
    ready_n = select(tcp_fd + 1, &rset, &wset, NULL, &timeout);
    if(0 == ready_n)
    {
       	printf("select_error");
        errcode = -1;
    }
    else if(ready_n < 0)
    {
        printf("select_error");
        errcode = -1;
    }
    else
    {
    //    ESP_LOGI(TAG,"FD_ISSET(tcp_fd, &rset):%d\n FD_ISSET(tcp_fd, &wset):%d\n",
//                        (int)FD_ISSET(tcp_fd, &rset) , (int)FD_ISSET(tcp_fd, &wset));
         // test in linux environment,kernel version 3.5.0-23-generic
         // tcp server do not send msg to client after tcp connecting
        int ret;
        socklen_t len = sizeof(int);
        if(0 != getsockopt (tcp_fd, SOL_SOCKET, SO_ERROR, &ret, (socklen_t*)&len))
        {
            printf("getsocketopt failed\r\n");
            errcode = -1;
        }
       	// ESP_LOGI(TAG,"getsocketopt ret=%d errno %d\r\n",ret, errno);
        if(0 != ret)
        {
        	printf("getsocketopt ret=%d errno %d\r\n",ret, errno);
            errcode = -1;
        }
    }
#endif
	setsockopt(tcp_fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
	setsockopt(tcp_fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));

	/*
	int ret;
	socklen_t len = sizeof(int);
	if(0 != getsockopt (tcp_fd, SOL_SOCKET, SO_ERROR, &ret, (socklen_t*)&len))
	{
		printf("getsocketopt failed\r\n");
		errcode = -1;
	}
	// ESP_LOGI(TAG,"getsocketopt ret=%d errno %d\r\n",ret, errno);
	if(0 != ret)
	{
		printf("getsocketopt ret=%d errno %d\r\n",ret, errno);
		errcode = -1;
	}
	*/


    return errcode;
}
static void ICACHE_FLASH_ATTR  new_tcp_disconnect(int tcp_fd)
{
    close(tcp_fd);
}
static int ICACHE_FLASH_ATTR new_tcp_connect(in_addr_t srcip,const char* dst, unsigned short port)
{
	struct sockaddr_in servaddr;
	int tcp_fd;
	int flags;
	int reuse;

	if(NULL == dst)
	{
		return -1;
	}

	tcp_fd = socket(AF_INET, SOCK_STREAM, 0);
	if(tcp_fd < 0)
	{
		printf("creat socket tcp_fd failed\n");
		return -1;
	}

	/*���÷�����ģʽ*/
	flags = fcntl(tcp_fd, F_GETFL, 0);
	if(flags < 0 || fcntl(tcp_fd, F_SETFL, flags | O_NONBLOCK) < 0)
	{
		printf("fcntl: %s\n", strerror(errno));
		close(tcp_fd);
		return -1;
	}

	reuse = 1;
	/*
	if(setsockopt(tcp_fd, SOL_SOCKET, SO_REUSEADDR,
					(const char *) &reuse, sizeof( reuse ) ) != 0 )
	{
		close(tcp_fd);
		printf("set SO_REUSEADDR failed\n");
		return -1;
	}
	*/

	memset(&servaddr, 0, sizeof(struct sockaddr_in));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr(dst);
	servaddr.sin_port = htons(port);



	struct sockaddr_in src;
	memset(&src,0,sizeof(struct sockaddr_in));
	src.sin_addr.s_addr = srcip;//ʹ��sta�� ip
	src.sin_family = AF_INET;
	src.sin_port=htons(10000);
	//destAddr.sin_port = htons(PORT);
	
	//��һ�� ip
	//bind(tcp_fd,&src,sizeof(struct sockaddr));

	

	if(connect(tcp_fd, (struct sockaddr *)&servaddr, sizeof(struct sockaddr_in)) == 0)
	{
		return tcp_fd;
	}
	else
	{
		if(errno == EINPROGRESS)
		{
			printf("tcp conncet noblock\n");
			return tcp_fd;
		}
		else
		{
			close(tcp_fd);
			return -1;
		}
	}
}
static int ICACHE_FLASH_ATTR new_tcp_read(int tcp_fd, unsigned char* buf, unsigned short len)
{
    int ret = -1;

    if(buf == NULL)
    {
        return -1;
    }

	/*TCP��ȡ������Ҫ�жϴ�����*/
    ret = (int)(recv(tcp_fd, buf, len, MSG_DONTWAIT));
    if(ret <= 0)
    {
    	
        if(errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)
        {
            return 0;//OK
        }
        else
        {
        	printf("tcp����errono=%d",errno);
            return -1;
        }
    }
	
    return ret;
}


int ICACHE_FLASH_ATTR new_tcp_send(int tcp_fd, const unsigned char* buf, unsigned short len)
{
    int ret = -1;

    if(buf == NULL)
    {
        return -1;
    }

	/*TCP����������Ҫ�жϴ�����*/
    ret = (int)(send(tcp_fd, buf, len, MSG_DONTWAIT));
    if(ret < 0)
    {
        if(errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)
        {
            return 0;
        }
        else
        {
            return -1;
        }
    }
	printf("\r\n new_tcp_send=%d \r\n",ret);

    return ret;
}
/*
 * buffer��ʮ���������
 */
void hexdump(const unsigned char *buf, uint32 num)
{
    uint32 i = 0;
    for (; i < num; i++) 
    {
        printf("%02X ", buf[i]);
        if ((i+1)%8 == 0) 
            printf("\n");
    }
    printf("\n");
}

/*EDP*/
RecvBuffer* recv_buf;
EdpPacket* pkg;

void ICACHE_FLASH_ATTR tcp_client_parse(char *buffer ,int len)
{
	uint8 mtype;
	int rtn;
	recv_buf = NewBuffer();
	hexdump((const unsigned char *)buffer, len);
	/* �ɹ�������n���ֽڵ����� */
	WriteBytes(recv_buf, buffer, len);

	while(1)
	{
		/* ��ȡһ����ɵ�EDP�� */
		if ((pkg = GetEdpPacket(recv_buf)) == 0)
		{
			printf("need more bytes...\n");
			break;
			
		}
		/* ��ȡ���EDP������Ϣ���� */
		mtype = EdpPacketType(pkg);

		switch(mtype)
		{
			case CONNRESP:
				/* ����EDP�� - ������Ӧ */
				rtn = UnpackConnectResp(pkg);
				printf("recv connect resp, rtn: %d\n", rtn);
				break;
			default:
				break;

		}
	}

	DeleteBuffer(&recv_buf);



}


static void ICACHE_FLASH_ATTR tcp_client_task(void *pvParameters)
{
    int send_len = -1;
    int recv_len = -1;
    int recv_flag = 0;
    int input_len;
    int tcp_connect_flag = 0;

    EdpPacket* send_pkg;



	for(;;)
	{
		printf("\r\n waitforip \r\n");
		vTaskDelay(1000 / portTICK_RATE_MS);
		if(true==wifi_station_connected())
		{
			for(;;)
			{
				printf("\r\n got ip \r\n");
				vTaskDelay(1000 / portTICK_RATE_MS);


				  tcp_fd = new_tcp_connect( (in_addr_t)staip.addr,Host, Port);
				  if(tcp_fd < 0)
				  {
					  new_tcp_disconnect(tcp_fd);
					  printf("\r\n tcp connect failed \r\n");
					  break;
				  }
				  tcp_client_isconnect_flag=1;
				  tcp_connect_flag=0;

				  while(1)
				  {
					  //ֻ����һ��
					  if(tcp_connect_flag == 0)
					  {
						  if(new_tcp_state(tcp_fd)!= 0)
						  {
							  printf("\r\n tcp not connect \r\n");
							  break;
						   //  continue;
						  }
						  else
						  {
							  printf("\r\n tcp connect successuflly \r\n");
							  tcp_connect_flag = 1;
						  }
						  vTaskDelay(1000/portTICK_RATE_MS);
					  }		  

					  /*
					  fd_set read_set; 
					  struct timeval t_o; 
					  int ret;
					  
					  FD_ZERO(&read_set); 
					  FD_SET(tcp_fd,&read_set); 
					  t_o.tv_sec = 1; 
					  ret = select(tcp_fd + 1,&read_set,NULL,NULL,&t_o); 
					  if(ret == 1) 
					  {  
						  if(FD_ISSET(tcp_fd,&read_set))
						  {
							 count = recv(lSockFd,buf,LEN,0); 
							 if((count == 0)||(count == -1)) 
							 { 
							 	//ʧ��
							 }
						  	
						  }
					  }
					  */
					  clienttcp_task_cont++;
					  if(clienttcp_task_cont==50002)
						  clienttcp_task_cont=0;

					  	  
					  if(clienttcp_task_cont==100)//2s
					  {
						  clienttcp_task_cont=0;
						  /*
						  memset(tcp_reveive_buffer, 0, tcp_max_size);
						  strcpy((char*)tcp_reveive_buffer,"123456789123444sadfasdf");
						 
						  input_len = strlen((char*)tcp_reveive_buffer);

						  send_len = new_tcp_send(tcp_fd, tcp_reveive_buffer, input_len-1);
						  */


						  send_pkg = PacketConnect1("508861595", "dUmdTtj1ccVP3THeRMUXQ9qi6LU=");
						  printf("\r\n PacketConnect1 ok \r\n");
						  send_len=new_tcp_send(tcp_fd, (const char*)send_pkg->_data, send_pkg->_write_pos);
						  if(send_len < 0)
						  {
							  printf("\r\n send tcp packet failed \r\n");
							  break;
						  }

						  DeleteBuffer(&send_pkg);

						  
						  clilenttcp_get_answer_cont=1;//���ظ�

					  }

						//  if(FD_ISSET(tcp_fd , &read_set))
						{
						  recv_len = new_tcp_read(tcp_fd, tcp_reveive_buffer, tcp_max_size-1);
						  if(recv_len > 0)
						  {
						 	  clilenttcp_get_answer;
							  recv_flag = 0;
							  printf("\r\n recv data:%s,length:%d \n", tcp_reveive_buffer, recv_len);
							//  InterNet_Receive(&tcp_reveive_buffer,recv_len);
							  tcp_client_parse((char *)&tcp_reveive_buffer,recv_len);
							  clilenttcp_get_answer=1;
						  }
						  else if(recv_len == 0)
						  {
							 // ESP_LOGI(TAG,"recv no data\n");
							//	continue;
						  }
						  else
						  {
						  	
							  printf("\r\n tcp read failed \r\n");
							  break;
						  }  

						}

						if(clilenttcp_get_answer_cont>0||(clilenttcp_get_answer))
						{

							if(clilenttcp_get_answer_cont++==200)//6Sû���յ��ظ�
							{
								clilenttcp_get_answer_cont=0;
								if(!clilenttcp_get_answer)
								{
									printf("\r\n ������û�лظ� �Ͽ� \r\n");
									//if(clienttcp_status==clienttcp_status_CLREND)//�����CLA֮���״̬
									break;
									
								}
							}
							if(clilenttcp_get_answer==1)
							{
								clilenttcp_get_answer_cont=0;
								clilenttcp_get_answer=0;
								printf("\r\n �������лظ� \r\n ");
							}

						}

					  
					  if(false == wifi_station_connected())
					  break;

					 vTaskDelay(30/portTICK_RATE_MS);

				  }
				new_tcp_disconnect(tcp_fd);
				tcp_client_isconnect_flag=0;
				if(false == wifi_station_connected())
				break;
			}
		}
		//CLIENT_END:
	}
}

xTaskHandle  ICACHE_FLASH_ATTR tcp_client_handle_get()
{
	return 	wifiClientHandle;
}

void ICACHE_FLASH_ATTR tcp_client_start()
{
	xTaskCreate(tcp_client_task, "tcp_client", 4096, NULL, 10, tcp_client_handle_get());
}

uint8_t ICACHE_FLASH_ATTR tcp_client_isconnect()
{
	return tcp_client_isconnect_flag;
}




