#ifndef __MYTCP_H__
#define __MYTCP_H__

#include "esp_common.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"

#include "user_config.h"
#include "wifi_state_machine.h"



#include "lwip/err.h"
#include "lwip/sockets.h"
#include "lwip/sys.h"
#include <lwip/netdb.h>


extern xTaskHandle tcp_client_handle_get();
void tcp_client_start();

uint8_t tcp_client_isconnect();


#endif
